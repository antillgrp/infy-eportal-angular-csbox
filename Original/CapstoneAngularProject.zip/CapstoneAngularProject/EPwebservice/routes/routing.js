var express = require('express');
var routing = express.Router();
var EmployeeDAL = require('../public/javascripts/EmployeeDAL');
var LoginDAL = require('../public/javascripts/LoginDAL');

// login
routing.post('/login', function(req, res, next) {
    let login = { username: req.body.username, password: req.body.password };
    LoginDAL.login(login).then(data => {
        if(data){
            res.json({message:true})
        }else{
            res.json({message:data.message})
        }
    }).catch(error => {
        res.json({message: false})
    })
})


routing.get('/getallEmployee', function (req, res, next) {

    EmployeeDAL.getAllBookingId().then(function (bookings) {

        res.json(bookings)
    }).catch(function () {
        next(err)
    })
})

routing.post('/addEmployee', function (req, res, next) {

    var employee = {
        empId: req.body.empId,
        empName: req.body.empName,
        empLocation: req.body.empLocation,
        jobLevel: req.body.jobLevel,
        onSite: true,
        emailId: req.body.emailId,
        skills: ['HTML5', 'CSS3', 'Javascript'],
        gender: req.body.gender,
        yearOfExperience: req.body.yearOfExperience,
        noOfProjectsWorked: req.body.noOfProjectsWorked,
        phoneNo: req.body.phoneNo,
        manager: 'john'
    }
    EmployeeDAL.findEmployee(employee).then(function(employee) {   
        if(employee === true) {
            res.json({message: 'Employee Added Successfully'})
        } else {
            res.json({message: 'Some Error Occurred'})
        }
    }).catch(function (err) {
        next(err)
    })
})


module.exports = routing;