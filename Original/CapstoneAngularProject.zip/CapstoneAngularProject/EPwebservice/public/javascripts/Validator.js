var Validator = {};

module.exports = Validator;