var connection = require('./connections');
var Employee = require('./Employee');

var EmployeeDAL = {}

EmployeeDAL.retrieveEmployee = function (empId) {
    return connection.getConnection().then(function (db) {
        return db.collection("Employees").findOne({ "empId": Number(empId) }).then(function (saved) {
            if (!saved) throw new Error("No record with this emp Id: " + empId);
            else return Employee.toObject(saved);
        });
    });
}

EmployeeDAL.getAllBookingId =function() {
    return connection.getConnection().then(function (db) {
        return db.collection("Employees").find().toArray().then(function(empDetails){
           return empDetails;            
        }).catch(function(err){
            return err;
        })
    })
}

EmployeeDAL.addNewEmployee = function(employee) {
    return connection.getConnection().then(function (db) {
        return db.collection("Employees").insert(employee).then(function (saved) {
            if (saved.insertedCount === 1) return true;
            else return false;
        }).catch(function(err) {
            return err;
        })
    });
}

EmployeeDAL.findEmployee = function(employee) {
    return connection.getConnection().then(function (db) {
        return db.collection("Employees").findOne({empId: employee.empId}).then(function (saved) {
            if (saved != null) throw new Error("Employee already present: " + employee.empName);
            else return EmployeeDAL.addNewEmployee(employee);
        });
    });
}

module.exports = EmployeeDAL;

