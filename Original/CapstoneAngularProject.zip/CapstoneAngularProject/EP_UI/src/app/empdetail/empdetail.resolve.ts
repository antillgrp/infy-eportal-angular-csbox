import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Employee } from '../employee';

@Injectable({
    providedIn: 'root'
})
export class EmpDetailResolve implements Resolve<Employee[]> {

    constructor() { }

    resolve(route: ActivatedRouteSnapshot): Observable<any> {
        // retrieve employee detail for selected empId
        return ;
    }
}
