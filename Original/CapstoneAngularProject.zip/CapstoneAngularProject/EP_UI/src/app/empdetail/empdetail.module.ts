import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmpDetailRoutingModule } from './empdetail-routing.module';


@NgModule({
  declarations: [
    
  ],
  imports: [
    CommonModule,
    EmpDetailRoutingModule
  ]
})
export class EmpDetailModule { }
