import { AttributeDirective } from './attribute.directive';

describe('AttributeDirective', () => {
  it('should create an instance', () => {
    const directive = new AttributeDirective();
    expect(directive).toBeTruthy();
  });
});
